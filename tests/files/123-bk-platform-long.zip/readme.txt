eCat3 platform launch test
